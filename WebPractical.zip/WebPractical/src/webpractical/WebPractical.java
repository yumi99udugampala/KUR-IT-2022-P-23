/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package webpractical;


public class WebPractical {

    
    public static void main(String[] args) {
        
        String myName = "Piyumi Udugampala";
        int myAge = 26;
        String mySchool = "Holy Family Convent";
        String myHobby = "Reading";
        System.out.println("Name: " + myName);
        System.out.println("Age: " + myAge);
        System.out.println("School: " + mySchool);
        System.out.println("Hobby: " + myHobby);
    }
}

    
    


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package webpractical;


public class Question4 {
   
    public static void main(String[] args) {
        int x = 125, y = 24;
        System.out.println("Sum: " + (x + y));
        System.out.println("Multiply: " + (x * y));
        System.out.println("Subtract: " + (x - y));
        System.out.println("Divide: " + (x / y));
        System.out.println("Remainder: " + (x % y));
    }
}
 


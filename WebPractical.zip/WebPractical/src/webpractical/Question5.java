/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package webpractical;

import java.util.Scanner;
import java.util.Calendar;

public class Question5 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your name: ");
        String name = scanner.nextLine();
        System.out.print("Enter your age: ");
        int age = scanner.nextInt();
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        int yearWhen100 = currentYear + (100 - age);
        System.out.println("Hi" + name + ", you will turn 100 years old in the year " + yearWhen100 + ".");
    }
}
  


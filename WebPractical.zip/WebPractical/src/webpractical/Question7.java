/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package webpractical;
import java.util.Scanner;

public class Question7 {
  
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] marks = new int[5];
        String[] subjects = {"Science", "Maths", "English", "IT", "History"};

        int total = 0;
        for (int i = 0; i < 5; i++) {
            System.out.print("Enter marks for " + subjects[i] + ": ");
            marks[i] = scanner.nextInt();
            total += marks[i];
        }

        double average = total / 5.0;
        String grade;

        if (average < 45) grade = "F";
        else if (average <= 55) grade = "S";
        else if (average <= 65) grade = "C";
        else if (average <= 75) grade = "B";
        else grade = "A";

        System.out.println("Total: " + total);
        System.out.println("Average: " + average);
        System.out.println("Grade: " + grade);
    }
}
  

